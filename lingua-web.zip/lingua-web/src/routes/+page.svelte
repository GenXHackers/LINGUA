<script lang="ts">
	import { browser } from '$app/environment';
	import { io, Socket } from 'socket.io-client';
	import { onMount, onDestroy } from 'svelte';
	let splashScreenDiv: HTMLDivElement | null;
	let socket: Socket;
	let translationLanguages: string[][];
	let translatedAudio: HTMLAudioElement | null = null;
	let sourceAudio: HTMLAudioElement | null = null;
	let text: string;
	let translationLanguageCode: string = 'ta';
	let translationLanguageName: string = 'Tamil';
	let translationResultText: string | undefined;
	let translationResultAudioURL: string | undefined;
	let isTranslationLoading: boolean = false;
	let videoFeedURL: string | undefined = undefined;
	let predictionResult: any;
	let img: string;
	const predictionsActions = [
		{
			action: 'Backspace',
			icon: 'backspace'
		},
		{
			action: 'Next',
			icon: 'keyboard_tab'
		},
		{
			action: 'Space',
			icon: 'space_bar'
		},
		{
			action: 'Clear',
			icon: 'delete_forever'
		}
	];

	$: translationLanguageName = (translationLanguages?.find(
		(tl) => tl[1] == translationLanguageCode
	) ?? ['', ''])[0];

	$: {
		translationLanguageCode;
		translationResultText = undefined;
		translationResultAudioURL = undefined;
	}

	function base64ToArrayBuffer(base64: string) {
		var binaryString = atob(base64);
		var bytes = new Uint8Array(binaryString.length);
		for (var i = 0; i < binaryString.length; i++) {
			bytes[i] = binaryString.charCodeAt(i);
		}
		return bytes.buffer;
	}
	async function getLanguages() {
		const res = await fetch(`http://127.0.0.1:5050/languages`);
		return await res.json();
	}
	async function getTranslation(dt?: { sntc: string; lc: string }) {
		if (!dt) isTranslationLoading = true;
		const params = new URLSearchParams({ text: dt ? dt.sntc : text });
		const res = await fetch(
			`http://127.0.0.1:5050/translate/${dt ? dt.lc : translationLanguageCode}?${params}`
		);
		const { audio, result } = await res.json();
		let bytes = base64ToArrayBuffer(audio);
		const blob = new Blob([bytes], { type: 'audio/mp3' });
		const audioURL = window.URL.createObjectURL(blob);
		if (!dt) isTranslationLoading = false;
		if (!dt) {
			translationResultText = result;
			translationResultAudioURL = audioURL;
		}
		return [result, audioURL];
	}
	function handlePredictionsAction(action: string) {
		socket.emit(`predictions ${action.toLowerCase()}`);
	}
	function handleSuggestionClick(suggestion: string) {
		socket.emit(`predictions suggestion`, suggestion);
	}
	function handleSourcePlaySpeechClick() {
		if (!text || text === '') return;

		getTranslation({ sntc: text, lc: 'en' }).then((res) => {
			if (sourceAudio) {
				sourceAudio.src = res[1];
				sourceAudio.autoplay = true;
			}
		});
	}
	function handleWindowKeyUp(event: KeyboardEvent) {
		switch (event.key.toLowerCase()) {
			case ' ':
				handlePredictionsAction('space');
				break;
			case 'backspace':
				handlePredictionsAction('backspace');
				break;
			case 'enter':
				handlePredictionsAction('next');
				break;
			case 'delete':
				handlePredictionsAction('clear');
				break;
			default:
				break;
		}
	}
	onMount(() => {
		socket = io('http://127.0.0.1:5000', {
			autoConnect: false,
			transports: ['websocket']
		});
		socket.on('video feed', (data) => {
			img = data;
		});
		socket.on('predictions', (data) => {
			text = data?.str;
			if (data.word_suggestions)
				data.word_suggestions = data.word_suggestions
					.filter((w: any) => w.length >= data?.word?.length)
					.sort((a: any, b: any) => b.length - a.length)
					.sort(
						(a: any, b: any) => a.slice(0, data?.word?.length) === b.slice(0, data?.word?.length)
					);
			if (predictionResult?.str != data.str) {
				translationResultText = undefined;
				translationResultAudioURL = undefined;
			}
			predictionResult = data;
		});
		socket.on('connect_error', (err) => {
			console.error(err);
		});
		socket.on('connect', function () {
			console.log('Connected');
			videoFeedURL = `http://127.0.0.1:5000/video_feed?sid=${socket.id}`;
			socket.emit('video feed start');
			splashScreenDiv?.classList.add('hidden');
		});
		socket.connect();
		getLanguages().then((v) => {
			translationLanguages = v;
		});
		document.addEventListener('keyup', handleWindowKeyUp);
	});
	onDestroy(() => {
		socket?.disconnect();
		if (browser) document.removeEventListener('keyup', handleWindowKeyUp);
	});
</script>

<div
	class="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black"
	bind:this={splashScreenDiv}
>
	<img src="/icon.jpeg" class="h-1/2 rounded-full" alt="" />
	<p class="text-4xl font-semibold text-white">Loading...</p>
</div>
<div class="flex gap-10">
	<div class="flex h-fit flex-grow flex-col space-y-5">
		<div class="flex w-full flex-wrap justify-center gap-4 text-xl">
			{#each predictionsActions as predAction}
				<button
					class="flex items-center space-x-2 rounded-md border px-4 py-2 font-semibold"
					on:click={() => handlePredictionsAction(predAction.action)}
				>
					<span class="material-symbols-rounded">{predAction.icon}</span>
					<p>{predAction.action}</p>
				</button>
			{/each}
		</div>
		{#if img}
			<img class="h-[50dvh] max-w-[50dvw] self-center rounded-xl" src={img} alt="webcam feed" />
		{/if}
		<div class="flex-grow text-2xl">
			<p>Character:</p>
			<p class="text-4xl font-semibold text-blue-700">
				{(predictionResult?.ch ?? '').toUpperCase()}
			</p>
		</div>
		<div class="text-2xl">
			<p>Word:</p>
			<p class="font-semibold text-blue-700">{(predictionResult?.word ?? '').toUpperCase()}</p>
		</div>
	</div>
	<div class="flex h-fit w-[40%] flex-grow flex-col space-y-5">
		<div
			class="rounded-lg bg-slate-50 p-4 transition-all {!translationResultText &&
			!isTranslationLoading
				? 'h-auto'
				: 'h-0'} overflow-hidden"
		>
			<div class="flex items-center space-x-3 pb-2">
				<p class="text-center text-xl font-semibold text-slate-700">Suggestions</p>
			</div>
			<div class="flex flex-wrap gap-2 text-xl">
				{#if predictionResult?.word_suggestions}
					{#each predictionResult?.word_suggestions as wsugg}
						<button
							class="rounded-full bg-blue-200 px-6 py-2 font-semibold"
							on:click={() => handleSuggestionClick(wsugg)}>{wsugg}</button
						>
					{/each}
				{:else}
					<p class="text-sm text-slate-600">No Suggestions</p>
				{/if}
			</div>
		</div>
		<div
			class="relative min-h-[200px] rounded-2xl border
        p-5 text-4xl"
		>
			<textarea class="h-full w-full bg-transparent p-4 outline-none" bind:value={text}></textarea>
			<div class="absolute inset-x-5 bottom-4 flex items-center gap-2">
				<p class="pl-4 text-3xl font-semibold text-blue-800">English</p>
				<div class="flex-grow"></div>
				<div class="flex items-stretch space-x-2 rounded-full bg-blue-300">
					<select
						class="w-fit appearance-none rounded-l-full border border-transparent bg-transparent px-4 py-1 text-2xl outline-none"
						bind:value={translationLanguageCode}
					>
						{#if translationLanguages}
							{#each translationLanguages as language, i}
								<option class="bg-slate-100 text-lg text-black" value={language[1]}
									>{language[0]}</option
								>
							{/each}
						{/if}
					</select>
					<button
						class="flex h-14 w-14 items-center justify-center rounded-full bg-blue-800 text-white"
						on:click={() => getTranslation()}
					>
						<span class="material-symbols-rounded h-8 text-3xl">translate</span></button
					>
				</div>
				<button
					class="flex h-14 w-14 items-center justify-center rounded-full bg-blue-800 text-white"
					on:click={handleSourcePlaySpeechClick}
				>
					<span class="material-symbols-rounded h-8 text-3xl">play_arrow</span></button
				>
			</div>
			<audio bind:this={sourceAudio}></audio>
		</div>
		<div
			class="relative min-h-[200px] rounded-2xl border
        p-5 text-4xl {!translationResultText && !isTranslationLoading ? 'hidden' : ''}"
		>
			<p class="p-5 {translationResultText && !isTranslationLoading ? '' : 'text-black/70'}">
				{!isTranslationLoading
					? (translationResultText ?? 'Click the translate button to continue...')
					: 'Loading...'}
			</p>
			<div class="absolute inset-x-5 bottom-4 flex items-center gap-2">
				<p class="pl-4 text-3xl font-semibold text-blue-800">
					{translationLanguageName}
				</p>
				<div class="flex-grow"></div>
				<button
					class="flex h-14 w-14 items-center justify-center rounded-full bg-blue-800 text-white"
					on:click={() => {
						translatedAudio?.play();
					}}
					disabled={!translationResultAudioURL}
				>
					<span class="material-symbols-rounded h-8 text-3xl">play_arrow</span></button
				>
			</div>
			<audio bind:this={translatedAudio} src={translationResultAudioURL}></audio>
		</div>
	</div>
</div>
