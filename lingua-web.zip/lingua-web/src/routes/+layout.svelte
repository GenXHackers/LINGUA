<script lang="ts">
	import '../app.css';
</script>

<div class="flex flex-col overflow-y-auto overflow-x-hidden">
	<div class="p-10">
		<slot></slot>
	</div>
	<!-- <div class="sticky bottom-0 min-h-12 bg-blue-800"></div> -->
</div>
